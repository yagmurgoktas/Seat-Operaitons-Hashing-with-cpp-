/*
Student Name:Yagmur Goktas
Student Number:2017400018
Project Number: 3
Compile Status: [SUCCESS/FAIL]
Running Status: [SUCCESS/FAIL]
Notes: Anything you want to say about your code that will be helpful in the grading process.
*/
#include "SeatOperations.h"

using namespace std;

SeatOperations::SeatOperations(int N, int M){
    // IMPLEMENT ME!
    this->M=M;
    this->N=N;
    Person* p = new Person();


    for(int i=1;i<=N;i++){
        this->lineA.push_back(*p);
    }
    for(int j=1;j<=M;j++){
        this->lineB.push_back(*p);
    }

    delete p;


}
void SeatOperations:: seatA(Person &person,int a){

        if(lineA[a].line=='Z'){
            lineA[a].line=person.line;
            lineA[a].type3LastOperation=person.type3LastOperation;
            lineA[a].type=person.type;
            lineA[a].seatNumber=person.seatNumber;
        }else {
            Person* temp=new Person();
            temp->type=lineA[a].type;
            temp->seatNumber=lineA[a].seatNumber;
            temp->type3LastOperation=lineA[a].type3LastOperation;
            temp->line=lineA[a].line;
            lineA[a]=person;

            if ((*temp).type == 1) {
                a=((*temp).seatNumber-1+M)%M;
                seatB((*temp),a);

            } else if ((*temp).type == 2) {
                if(a==N-1){
                    seatB((*temp),0);
                }
                else {
                    seatA((*temp), a+1);
                }


            } else if ((*temp).type == 3) {

                a = (a + ((2*(*temp).type3LastOperation)+1)) % (M+N);
                (*temp).type3LastOperation++;

                //int h=(((*temp).type3LastOperation)*((*temp).type3LastOperation));
                //a=((((*temp).seatNumber-1+N)%N)+h)%(N+M);
                if(a<N) {
                    seatA((*temp), a);
                }
                else{

                    a=a-N;
                    seatB((*temp),a);
                }


            }
            delete temp;
        }
}
void SeatOperations::seatB(Person &person,int a){
    if(lineB[a].line=='Z'){
        lineB[a].type=person.type;
        lineB[a].seatNumber=person.seatNumber;
        lineB[a].type3LastOperation=person.type3LastOperation;
        lineB[a].line=person.line;
    }else {

        Person* temp=new Person();
        temp->type=lineB[a].type;
        temp->seatNumber=lineB[a].seatNumber;
        temp->type3LastOperation=lineB[a].type3LastOperation;
        temp->line=lineB[a].line;
        lineB[a]=person;

        if ((*temp).type == 1) {
            a=((*temp).seatNumber-1)%N;
            seatA((*temp),a);

        } else if ((*temp).type == 2) {


            if(a==M-1){
                seatA((*temp),0);
            }
            else {
                seatB((*temp), a+1);
            }

        } else if ((*temp).type == 3) {


            a = (a + ((2*(*temp).type3LastOperation)+1)) % (M+N);
            (*temp).type3LastOperation++;
            //int h=(((*temp).type3LastOperation)*((*temp).type3LastOperation));
            //a=((((*temp).seatNumber-1+M)%M)+h)%(N+M);

            if(a<M) {
                seatB(*temp, a);
            }
            else{
               a=a-M;

                seatA(*temp,a);
            }

        }
        delete temp;
    }


}
void SeatOperations::addNewPerson(int personType, const string& ticketInfo){
    // IMPLEMENT ME!
    Person pe;
    (pe).line=ticketInfo[0];
    (pe).type=personType;
    (pe).type3LastOperation=0;
    string s= ticketInfo.substr(1,ticketInfo.length());
    (pe).seatNumber=stoi(s);

    if((pe).line=='A'){
        seatA(pe,((pe.seatNumber-1+N)%N));
    }else if((pe).line=='B'){
        seatB(pe,((pe.seatNumber-1+M)%M));
    }

}



void SeatOperations::printAllSeats(ofstream& outFile){
    // IMPLEMENT ME!
    for(int i=0;i<N;i++){
        if(lineA[i].type!=0) {
            outFile << lineA[i].type << " ";
            outFile << lineA[i].line;
            outFile << lineA[i].seatNumber << endl;
        }
        else{
            outFile << 0 << endl;
        }
    }
    for(int j=0;j<M;j++){
        if(lineB[j].type!=0) {
            outFile << lineB[j].type << " ";
            outFile << lineB[j].line;
            outFile << lineB[j].seatNumber << endl;
        }
        else{
            outFile << 0 << endl;
        }
    }

}

// YOU CAN ADD YOUR HELPER FUNCTIONS